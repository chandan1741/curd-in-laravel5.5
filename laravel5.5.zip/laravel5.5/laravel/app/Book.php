<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Book extends Model
{
	// protected $table ='my_table';
	// protected $guarded =[];
    protected $fillable = [
        'user_id', 'book'
    ];

    public $timestamps=false;
}
