<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class MyModel extends Model
{
    //
}
