<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use File;
use App\Book;
class UserController extends Controller
{
	//View all record
    public function index(){
    	$Users=User::with('books')->get()->toArray();
    	return view('welcome',['users' =>$Users]);
    }
    //Add user info
    public function userdata(Request $request)
    {
    	$data = $request->all();
    	// echo'<pre>';
    	// print_r($data);die;
    	if(!empty($data)) {
    		$imgdata = '';
    		if($request->hasFile('image')){

    			$file = $request->file('image');
    			$filename = $file->getClientOriginalName();
    			$extension = $file->getClientOriginalExtension();
    			if($extension=='jpg' || $extension=='png' || $extension=='jpeg'){
    				$imgname = uniqid().$filename;
	    			$path = public_path('/image/');
	    			$file->move($path,$imgname);
    			}else{
    				$request->session()->flash('alert-danger','file type not valid');
    				return redirect()->back();
    			}
    			
    		}
    		try{
    			$user = User::create(['name' => $data['name'],'phone_number' => $data['mob'],'email' => $data['email'],'message' => $data['mess'],'image'=>$imgname]);
    			Book::create(['user_id' =>$user->id,'book'=>$data['book']]); 
    		}catch(\Exception $e){
    			$request->session()->flash('alert-danger',$e->getMessage());
    			return redirect()->back();
    		}
    			$request->session()->flash('alert-success','Data Added successfully!');
    			return redirect()->back();
    	}else{
    		return redirect()->back();
    	}
    }

    public function editusers($id)
    {
    	// echo $id;die;
    	$id = convert_uudecode(base64_decode($id));
    	$userdata=User::with('books')->where('id',$id)->first()->toArray();
    	return view('edituser',['userdata' =>$userdata]);
    }
    //Delete user info
    public function deleteusers(Request $request,$id)
    {
    	$id = convert_uudecode(base64_decode($id));
    	try{
    		$oldimage = User::where('id',$id)->value('image');
    		$fullpath = public_path('/image/').$oldimage;
    		File::delete($fullpath);
    		User::where('id',$id)->delete();
    		$request->session()->flash('alert-success','Data deleted successfully');
    	}catch(\Exception $e){
    		$request->session()->flash('alert-danger','Data no deleted');
    	}
    	return redirect()->back();
    }
    //Update user info
    public function updateusers(Request $request)
    {
    	$data = $request->all();

    	if($request->hasFile('image')){
    		$oldimage = User::where('id',$data['userid'])->value('image');
    		$fullpath = public_path('/image/').$oldimage;
    		// echo $fullpath;die;
    		File::delete($fullpath);
    		$file = $request->file('image');
    		$filename = $file->getClientOriginalName();
    		$extension = $file->getClientOriginalExtension();
    		$imgname = uniqid().$filename;
    		$path = public_path('/image/');
    		$file->move($path,$imgname);
    		}else{
    		$imgname = User::where('id',$data['userid'])->value('image');	
    		}
    	try{
    		User::where('id',$data['userid'])->update(['name'=>$data['name'],'email'=>$data['email'],'phone_number'=>$data['mob'],'message'=>$data['mess'],'image'=>$imgname]);
    		Book::where('user_id',$data['userid'])->update(['book'=>$data['book']]);
    		$request->session()->flash('alert-success','Userdata updated successfully');
    	}catch(\Exception $e){
    		$request->session()->flash('alert-danger','Not updated');
    	}
    	return redirect()->to('/');
    	
    }
}
