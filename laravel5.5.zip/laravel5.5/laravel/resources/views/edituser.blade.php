<!doctype html>
<html lang="{{ app()->getLocale() }}">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
        <link href="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
        <link href="//cdn.datatables.net/1.10.18/css/dataTables.bootstrap.min.css">
        <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
        <script src="//cdn.datatables.net/1.10.18/js/dataTables.bootstrap.min.js"></script>
        <script src="//maxcdn.bootstrapcdn.com/bootstrap/3.3.0/js/bootstrap.min.js"></script>
        <!-- Styles -->
        <style>
            form_main {
    width: 100%;
}
.form_main h4 {
    font-family: roboto;
    font-size: 20px;
    font-weight: 300;
    margin-bottom: 15px;
    margin-top: 20px;
    text-transform: uppercase;
}
.heading {
    border-bottom: 1px solid #fcab0e;
    padding-bottom: 9px;
    position: relative;
}
.heading span {
    background: #9e6600 none repeat scroll 0 0;
    bottom: -2px;
    height: 3px;
    left: 0;
    position: absolute;
    width: 75px;
}   
.form {
    border-radius: 7px;
    padding: 6px;
}
.txt[type="text"] {
    border: 1px solid #ccc;
    margin: 10px 0;
    padding: 10px 0 10px 5px;
    width: 100%;
}
.txt[type="email"] {
    border: 1px solid #ccc;
    margin: 10px 0;
    padding: 10px 0 10px 5px;
    width: 100%;
}
.txt_3[type="text"] {
    margin: 10px 0 0;
    padding: 10px 0 10px 5px;
    width: 100%;
}
.txt2[type="submit"] {
    background: #242424 none repeat scroll 0 0;
    border: 1px solid #4f5c04;
    border-radius: 25px;
    color: #fff;
    font-size: 16px;
    font-style: normal;
    line-height: 35px;
    margin: 10px 0;
    padding: 0;
    text-transform: uppercase;
    width: 30%;
}
.txt2:hover {
    background: rgba(0, 0, 0, 0) none repeat scroll 0 0;
    color: #5793ef;
    transition: all 0.5s ease 0s;
}

        </style>
    </head>
    <body>
        


<div class="container">
    <div class="row">
    <div class="col-md-12">
        <div class="form_main">
                <h4 class="heading"><strong>Edit </strong> Userinfo <span></span></h4>
                <div class="flash-message">
                   @foreach (['danger', 'warning', 'success', 'info'] as $msg)
                     @if(Session::has('alert-' . $msg))

                       <p class="alert alert-{{ $msg }}">{{ Session::get('alert-' . $msg) }}
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">×</a>
                       </p>
                     @endif
                  @endforeach
                </div> 
                <div class="form">
                <form action="{{url('/update-users')}}" method="post" id="contactFrm" name="contactFrm" enctype="multipart/form-data">
                    {{ csrf_field()}}
                    <input type="hidden" name="userid" value="{{$userdata['id']}}">
                    <input type="text" required="" value="{{$userdata['name']}}" placeholder="Please input your Name" value="" name="name" class="txt" maxlength="75">
                    <input type="text" required="" value="{{$userdata['phone_number']}}" placeholder="Please input your mobile No" value="" name="mob" class="txt" maxlength="10">
                    <input type="email" required="" value="{{$userdata['email']}}" placeholder="Please input your Email" value="" name="email" class="txt">
                    <div class="form-group">
                        <select class="form-control" name="book">
                            <option value="">Select Book</option>
                            <option value="book1" <?php if($userdata['books']['book'] == 'book1'){echo 'selected';}?>>book1</option>
                            <option value="book2" <?php if($userdata['books']['book'] == 'book2' ){echo 'selected';}?>>book2</option>
                            <option value="book3" <?php if($userdata['books']['book'] == 'book3'){echo 'selected';}?>>book3</option>
                        </select>
                    </div>

                    
                     <textarea placeholder="Your Message" name="mess" maxlength="100" type="text" class="txt_3" >
                         {{$userdata['message']}}
                     </textarea>
                     <input type="file" name="image" class="txt form-group">
                     <img src="{{asset('public/image/'.$userdata['image'])}}" width="200px" height="200px" /><br><br>
                     <button type="submit" class="btn btn-success">submit</button>
                     <!-- <input type="submit" value="submit" name="submit" class="txt2"> -->
                </form>
            </div>
            </div>
            </div>
    </div>
</div>
    </body>
</html>
